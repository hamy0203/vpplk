// slides.js
(() => {
  let appData = window.APP_DATA;
  if (!appData || !Array.isArray(appData.units)) {
    throw new Error("Missing APP_DATA.units in slides-data.js");
  }

  // ===== EDITOR MODE =====
  // Kích hoạt bằng cách click vào brand 5 lần liên tiếp

  // ===== DOM =====
  const $ = (sel) => document.querySelector(sel);

  const video = $("#video");
  const slideImg = $("#slideImg");
  const overlayLayer = $("#overlayLayer");
  const captionBox = $("#captionBox");
  const captionEn = $("#captionEn");
  const captionLocal = $("#captionLocal");
  const noteBox = $("#noteBox");

  const languageSelect = $("#languageSelect");
  const unitSelect = $("#unitSelect");
  const btnRefresh = $("#btnRefresh");
  const btnPrevSlide = $("#btnPrevSlide");
  const btnNextSlide = $("#btnNextSlide");

  const brand = $("#brand");
  const glossaryPanel = $("#glossaryPanel");
  const glossarySearch = $("#glossarySearch");
  const glossaryBox = $("#glossaryBox");
  const editorHints = $("#editorHints");
  const btnToggleGlossary = $("#btnToggleGlossary");

  // ===== STATE =====
  //Mặc định hiển thị phụ đề tiếng Anh
  let currentLanguage = localStorage.getItem("currentLanguage") || "en";

  // Return the current unit when F5 browser
  let currentUnitId =
    localStorage.getItem("currentUnitId") ||
    appData.defaultUnit ||
    appData.units[0]?.id ||
    "";

  let SLIDES = [];
  let CAPTIONS = [];
  let currentSlideIndex = 0;

  let showingGlossary = false;

  // ===== HELPERS =====
  function getUnitById(id) {
    return appData.units.find((u) => u.id === id) || null;
  }

  function findSlideIndexByTime(t) {
    for (let i = 0; i < SLIDES.length; i++) {
      if (t >= SLIDES[i].start && t < SLIDES[i].end) return i;
    }
    if (!SLIDES.length) return -1;
    if (t < SLIDES[0].start) return 0;
    return SLIDES.length - 1;
  }

  function findCaptionByTime(t) {
    for (let i = 0; i < CAPTIONS.length; i++) {
      if (t >= CAPTIONS[i].start && t < CAPTIONS[i].end) return CAPTIONS[i];
    }
    return null;
  }

  function reloadSlidesData() {
  return new Promise((resolve, reject) => {
    const oldScript = document.getElementById("slidesDataScript");
    if (oldScript) oldScript.remove();

    delete window.APP_DATA;

    const script = document.createElement("script");
    script.id = "slidesDataScript";
    script.src = `./slides-data.js?v=${Date.now()}`;

    script.onload = () => {
      appData = window.APP_DATA;

      if (!appData || !Array.isArray(appData.units)) {
        reject(new Error("Reloaded APP_DATA is invalid"));
        return;
      }

      resolve(appData);
    };

    script.onerror = () => {
      reject(new Error("Cannot reload slides-data.js"));
    };

    document.head.appendChild(script);
  });
  }

  function updateLanguageUI() {
  if (!languageSelect) return;
  languageSelect.value = currentLanguage;
}

  function renderCaptionByTime(t) {
  if (!captionBox || !captionEn || !captionLocal) return;

  const c = findCaptionByTime(t);
  if (!c || !c.text) {
    captionEn.textContent = "";
    captionLocal.textContent = "";
    captionLocal.style.display = "none";
    return;
  }

  const text = c.text || {};
  const en = text.en || text.vi || "";
  const local =
    currentLanguage === "en"
      ? ""
      : currentLanguage === "kh"
      ? (text.kh || text.vi || en)
      : currentLanguage === "la"
      ? (text.la || text.vi || en)
      : (text.vi || en);

  captionEn.textContent = en;

  if (currentLanguage === "en") {
    captionLocal.textContent = "";
    captionLocal.style.display = "none";
  } else {
    captionLocal.textContent = local;
    captionLocal.style.display = "block";
  }
}

  function renderOverlays(slide) {
    if (!overlayLayer) return;
    overlayLayer.innerHTML = "";

    if (!slide) return;

    // Slide gốc đã có tiếng Việt, không cần overlay
    if (currentLanguage === "vi") return;

    const overlays = getOverlayList(slide);
    if (!overlays.length) return;

    overlays.forEach((o) => {
      const box = document.createElement("div");
      box.className = "overlay-box";
      box.textContent = getOverlayText(o);

      // Text style - Các định dạng phụ đề
      if (o.fontSize != null) box.style.fontSize = o.fontSize + "px";
      if (o.lineHeight != null) box.style.lineHeight = String(o.lineHeight);
      if (o.padding != null) box.style.padding = o.padding;
      if (o.nowrap === false) box.style.whiteSpace = "pre-wrap";

      if (o.italic || o.italics) box.style.fontStyle = "italic";
      if (o.bold) box.style.fontWeight = "700";

      const deco = [];
      if (o.underline) deco.push("underline");
      if (o.strike) deco.push("line-through");
      if (deco.length) box.style.textDecoration = deco.join(" ");

      if (o.align) {
        box.style.textAlign = o.align;
        box.style.justifyContent =
          o.align === "left" ? "flex-start" :
          o.align === "right" ? "flex-end" :
          "center";
      }

      if (o.color) box.style.color = o.color;
      if (o.bg) box.style.background = o.bg;

      // Text align - Căn lề phụ đề
      box.style.left = (o.left ?? 0) + "%";
      box.style.top = (o.top ?? 0) + "%";
      if (o.width != null) box.style.width = o.width + "%";
      if (o.height != null) box.style.height = o.height + "%";

      overlayLayer.appendChild(box);
    });
  }

  function renderSlide(index) {
    if (!SLIDES.length || index < 0 || !SLIDES[index]) {
      currentSlideIndex = 0;
      if (slideImg) slideImg.removeAttribute("src");
      if (overlayLayer) overlayLayer.innerHTML = "";
      return;
    }

    const s = SLIDES[index];
    currentSlideIndex = index;

    if (slideImg) {
      slideImg.src = s.img;
      slideImg.alt = `Slide ${s.id}`;
    }

    renderOverlays(s);
    updateSlideNavButtons();
  }

  function updateSlideNavButtons() {
  if (btnPrevSlide) btnPrevSlide.disabled = currentSlideIndex <= 0;
  if (btnNextSlide) btnNextSlide.disabled = currentSlideIndex >= SLIDES.length - 1;
}

// Chức năng tua slide

function goToSlide(index) {
  if (!SLIDES.length) return;

  const clamped = Math.max(0, Math.min(index, SLIDES.length - 1));
  const slide = SLIDES[clamped];
  if (!slide) return;

  currentSlideIndex = clamped;
  renderSlide(clamped);

  const t = Number(slide.start) || 0;
  if (video) video.currentTime = t;

  renderCaptionByTime(t);
}

function goPrevSlide() {
  goToSlide(currentSlideIndex - 1);
}

function goNextSlide() {
  goToSlide(currentSlideIndex + 1);
}

  function renderNotes(unit) {
  if (!noteBox) return;
  if (!unit || !unit.notes) {
    noteBox.innerHTML = "";
    return;
  }

  const title = unit.notes.title || "";
  const items = unit.notes.items || [];

  noteBox.innerHTML = `
    <h2>${title}</h2>
    ${items.map((item) => `<p>${item}</p>`).join("")}
  `;
}

  function onTimeUpdate() {
    if (!video) return;

      const idx = findSlideIndexByTime(video.currentTime);
      if (idx !== -1 && idx !== currentSlideIndex) {
        renderSlide(idx);
      }

    renderCaptionByTime(video.currentTime);
  }

  function loadUnit(unitId, keepCurrentTime = false) {
    const unit = getUnitById(unitId);
    if (!unit) return;

    currentUnitId = unitId;
    localStorage.setItem("currentUnitId", unitId);

    SLIDES = unit.slides || [];
    CAPTIONS = unit.captions || [];

    renderNotes(unit);

    if (unitSelect) unitSelect.value = unitId;

    if (video) {
  const oldTime = video.currentTime || 0;
  const previewTime = keepCurrentTime ? oldTime : 0;

  const previewIdx = findSlideIndexByTime(previewTime);
  renderSlide(previewIdx === -1 ? 0 : previewIdx);
  renderCaptionByTime(previewTime);

  video.src = unit.video || "";
  video.load();

  video.addEventListener(
    "loadedmetadata",
    () => {
      const safeTime = keepCurrentTime ? Math.min(oldTime, video.duration || 0) : 0;
      video.currentTime = safeTime;

      const safeIdx = findSlideIndexByTime(safeTime);
      renderSlide(safeIdx === -1 ? 0 : safeIdx);
      renderCaptionByTime(safeTime);
    },
    { once: true }
  );
} else {
  renderSlide(0);
  renderCaptionByTime(0);
}
  }

  //Đồng loạt đổi ngôn ngữ

  function getUnitTitle(unit) {
  if (!unit) return "";

  const title = unit.title || {};

  if (currentLanguage === "en") return title.en || title.vi || "";
  if (currentLanguage === "kh") return title.kh || title.vi || title.en || "";
  if (currentLanguage === "la") return title.la || title.vi || title.en || "";
  return title.vi || title.en || "";
}

function getCaptionText(cap) {
  if (!cap) return "";

  const text = cap.text || {};

  if (currentLanguage === "en") return text.en || text.vi || "";
  if (currentLanguage === "kh") return text.kh || text.vi || text.en || "";
  if (currentLanguage === "la") return text.la || text.vi || text.en || "";
  return text.vi || text.en || "";
}

function getOverlayList(slide) {
  if (!slide) return [];
  return slide.overlays || [];
}

function getOverlayText(overlay) {
  if (!overlay) return "";

  const text = overlay.text || {};

  if (currentLanguage === "en") return text.en || text.vi || "";
  if (currentLanguage === "kh") return text.kh || text.vi || text.en || "";
  if (currentLanguage === "la") return text.la || text.vi || text.en || "";
  return text.vi || text.en || "";
}

// Nút Reload Data không reload video và slide
  async function refreshCurrentUnit() {
  const oldTime = video ? (video.currentTime || 0) : 0;
  const wasPaused = video ? video.paused : true;

  try {
    await reloadSlidesData();

    const unit = getUnitById(currentUnitId);
    if (!unit) return;

    SLIDES = unit.slides || [];
    CAPTIONS = unit.captions || [];

    renderNotes(unit);

    const idx = findSlideIndexByTime(oldTime);
    renderSlide(idx === -1 ? 0 : idx);
    renderCaptionByTime(oldTime);

    if (video) {
      video.currentTime = oldTime;

      if (!wasPaused) {
        video.play().catch(() => {});
      }
    }
  } catch (err) {
    console.error(err);
    alert("Cannot reload slides-data.js");
  }
}

  // ===== EDITOR MODE TOGGLE =====

  // ===== GLOSSARY =====
  // Data source: glossary.js exposes window.GLOSSARY_TERMS; appData.glossary is a fallback.
  // Each entry: { vi, en, kh, la }
  // Display format per line: VI | EN | KH | LA — matching substring is bold.

  function getGlossaryTerms() {
    return window.GLOSSARY_TERMS || appData.glossary || [];
  }

  const GLOSSARY_PLACEHOLDER = {
    vi: "Tra cứu từ khoá…",
    en: "Look up a term…",
    kh: "ស្វែងរកពាក្យ…",
    la: "ຄົ້ນຫາຄຳສັບ…",
  };

  function updateGlossaryPlaceholder() {
    if (glossarySearch) {
      glossarySearch.placeholder = GLOSSARY_PLACEHOLDER[currentLanguage] || GLOSSARY_PLACEHOLDER.en;
    }
  }

  function escapeHtml(s) {
    return String(s || "")
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;");
  }

  // Wraps the matching substring in <strong>; returns plain escaped text otherwise
  function highlight(text, q) {
    const safe = escapeHtml(text);
    if (!q || !text) return safe;
    const idx = text.toLowerCase().indexOf(q);
    if (idx === -1) return safe;
    return escapeHtml(text.slice(0, idx))
      + `<strong>${escapeHtml(text.slice(idx, idx + q.length))}</strong>`
      + escapeHtml(text.slice(idx + q.length));
  }

  function renderGlossary(filter) {
    if (!glossaryBox) return;

    const terms = getGlossaryTerms();
    const q = (filter || "").trim().toLowerCase();

    const visible = q
      ? terms.filter((t) =>
          ["vi", "en", "kh", "la"].some((c) => (t[c] || "").toLowerCase().includes(q))
        )
      : terms;

    const collator = new Intl.Collator(undefined, { numeric: true, sensitivity: "base" });
    const sorted = [...visible].sort((a, b) => collator.compare(a.vi || "", b.vi || ""));

    if (!sorted.length) {
      glossaryBox.innerHTML = `<p class="glossary-empty">—</p>`;
      return;
    }

    const SEP = `<span class="glossary-sep">|</span>`;
    glossaryBox.innerHTML = sorted.map((t) => {
      const vi = highlight(t.vi || "—", q);
      const en = highlight(t.en || "—", q);
      const kh = highlight(t.kh || "—", q);
      const la = highlight(t.la || "—", q);
      return `<p class="glossary-entry">${vi}${SEP}${en}${SEP}${kh}${SEP}${la}</p>`;
    }).join("");
  }

  // Nhãn nút theo ngôn ngữ
  const BTN_LABELS = {
    prev:     { vi: "\u2039 Slide trước", en: "\u2039 Prev",    kh: "\u2039 មុន",    la: "\u2039 ກ່ອນ" },
    next:     { vi: "Slide sau \u203a",  en: "Next \u203a",    kh: "បន្ទាប់ \u203a", la: "ຕໍ່ໄປ \u203a" },
    glossary: { vi: "Từ khoá \u203a", en: "Glossary \u203a", kh: "វាក្យសព្ទ \u203a", la: "ຄຳສັບ \u203a" },
    keyIdeas: { vi: "\u2039 Tóm tắt",  en: "\u2039 Key Ideas", kh: "\u2039 គំនិតសំខាន់", la: "\u2039 ແນວຄິດຫຼັກ" },
  };

  function getBtnLabel(key) {
    const labels = BTN_LABELS[key];
    return (labels && labels[currentLanguage]) || labels.en || "";
  }

  function updateButtonLabels() {
    if (btnPrevSlide) btnPrevSlide.textContent = getBtnLabel("prev");
    if (btnNextSlide) btnNextSlide.textContent = getBtnLabel("next");
    if (btnToggleGlossary) {
      btnToggleGlossary.textContent = showingGlossary ? getBtnLabel("keyIdeas") : getBtnLabel("glossary");
    }
  }

  function setGlossaryView(show) {
    showingGlossary = show;
    if (noteBox) noteBox.hidden = show;
    if (glossaryPanel) glossaryPanel.hidden = !show;
    // Ẩn editor hints khi xem glossary
    if (editorHints) editorHints.hidden = show || !document.body.classList.contains("editor-mode");
    updateButtonLabels();
    if (show) {
      updateGlossaryPlaceholder();
      renderGlossary(glossarySearch ? glossarySearch.value : "");
      if (glossarySearch) glossarySearch.focus();
    }
  }

  const EDITOR_HINTS = [
    'TEXT FORMATTING:',
    'Đổi màu nền (bg:"#HEX")',
    'Đổi cỡ chữ (fontSize:18)',
    'Chữ nghiêng/gạch chân/gạch ngang (italic/underline/strike:true)',
    'Căn lề (align:"left/center/right")',
    'Chỉnh toạ độ (left/top/width/height)',
    'Gói gọn chữ: (nowrap:true)',
  ];

  function initEditorMode() {
    if (!brand) return;

    if (editorHints) {
      editorHints.innerHTML = EDITOR_HINTS.map((h) => `<code>${h}</code>`).join(" &nbsp;·&nbsp; ");
    }

    let clicks = 0;
    let timer;
    brand.addEventListener("click", () => {
      clicks++;
      clearTimeout(timer);
      timer = setTimeout(() => { clicks = 0; }, 2000);
      if (clicks >= 5) {
        clicks = 0;
        const isOn = document.body.classList.toggle("editor-mode");
        if (editorHints) editorHints.hidden = !isOn || showingGlossary;
      }
    });

    if (btnRefresh) {
      btnRefresh.addEventListener("click", () => {
        refreshCurrentUnit();
      });
    }
  }

  function init() {
    if (!video) throw new Error("Missing #video element");

    updateLanguageUI();
    if (languageSelect) {
  languageSelect.addEventListener("change", () => {
    currentLanguage = languageSelect.value;
    localStorage.setItem("currentLanguage", currentLanguage);
    updateLanguageUI();
    renderSlide(currentSlideIndex);

    const t = video ? (video.currentTime || 0) : 0;
    renderCaptionByTime(t);

    updateButtonLabels();

    if (showingGlossary) {
      updateGlossaryPlaceholder();
      renderGlossary(glossarySearch ? glossarySearch.value : "");
    }
  });
}

    if (unitSelect) {
      unitSelect.addEventListener("change", () => {
        loadUnit(unitSelect.value, false);
      });
    }

    if (btnToggleGlossary) {
      btnToggleGlossary.addEventListener("click", () => {
        setGlossaryView(!showingGlossary);
      });
    }

    if (glossarySearch) {
      glossarySearch.addEventListener("input", () => {
        renderGlossary(glossarySearch.value);
      });
    }

    video.addEventListener("timeupdate", onTimeUpdate);
    video.addEventListener("seeking", onTimeUpdate);
    video.addEventListener("seeked", onTimeUpdate);

    window.addEventListener("keydown", (e) => {
  const tag = e.target && e.target.tagName;
  if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return;

  if (e.key === "ArrowLeft") {
    e.preventDefault();
    goPrevSlide();
    return;
  }

  if (e.key === "ArrowRight") {
    e.preventDefault();
    goNextSlide();
    return;
  }
});

if (btnPrevSlide) {
  btnPrevSlide.addEventListener("click", () => {
    goPrevSlide();
  });
}

if (btnNextSlide) {
  btnNextSlide.addEventListener("click", () => {
    goNextSlide();
  });
}

    initEditorMode();
    setGlossaryView(false);
    loadUnit(currentUnitId, true);
  }

  document.addEventListener("DOMContentLoaded", init);
})();
