// glossary-data.js
// ---- Thêm từ vựng mới ở đây ----
// Add more terms as needed.
// Format: { vi: "...", en: "...", kh: "...", la: "..." }

window.GLOSSARY_TERMS = [
  { vi: "Chuối", en: "Banana", kh: "ចេក", la: "ກ້ວຍ" },
  { vi: "Luống", en: "Bed", kh: "", la: "" },
  { vi: "Lô", en: "Block", kh: "", la: "" },
  { vi: "Khu liên hợp", en: "Complex", kh: "", la: "" },
  { vi: "Xí nghiệp", en: "Enterprise", kh: "", la: "" },
  { vi: "Trồng dặm", en: "Gap filling", kh: "", la: "" },
  { vi: "Tổ", en: "Group", kh: "", la: "" },
  { vi: "Nông trường", en: "Plantation", kh: "", la: "" },
  { vi: "Thửa", en: "Plot", kh: "", la: "" },
  { vi: "Huỷ chồi", en: "Sucker pruning", kh: "", la: "" },
  { vi: "Đội", en: "Team", kh: "", la: "" },
  { vi: "Giống chuối", en: "Cultivar", kh: "", la: "" },
];
